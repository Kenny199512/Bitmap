﻿using System.Windows.Media;


public class Point2D {
    private int   _x = 0;
    private int   _y = 0; 
    private Color _pointColor;

    #region Properties
    public int X {
        get { return _x; }
        set { _x = value; }
    }
    public int Y {
        get { return _y; }
        set { _y = value; }
    }

    public Color ColorPoint {
        get { return _pointColor; }
    }

    #endregion // Properties


    #region METHODS
    public void SetPosition(int newX, int newY) {
        _x = newX;
        _y = newY;
    }

        public void SetColor(byte red, byte grn, byte blu) {
            _pointColor = Color.FromRgb(red, grn, blu);  
        }//end method

    /*public Color GetColor() {
        return _pointColor;
    }*/

    #endregion//Methods
}



