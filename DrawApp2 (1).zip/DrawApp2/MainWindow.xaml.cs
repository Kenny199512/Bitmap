﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DrawApp2 {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow:Window {
        #region FIELDS
        private Point2D         _mousePosition = new Point2D();
        private BitmapMaker     _bmpDraw;
        private Color           _drawColor = new Color();
        private SolidColorBrush mySolidColorBrush = new SolidColorBrush();

        #endregion

        #region CONSTRUCTOR
        public MainWindow() {
            InitializeComponent();
            SetupBitMap();
            _drawColor = Color.FromRgb(255,200,60);
            mySolidColorBrush.Color = _drawColor;
            rctCurrentColor.Fill = mySolidColorBrush;
        }
        #endregion

        #region EVENTS
        private void drawPad_MouseMove(object sender,MouseEventArgs mouseData) {
            //GET MOUSE X + Y
            int mouseX = (int)mouseData.GetPosition(drawPad).X;
            int mouseY = (int)mouseData.GetPosition(drawPad).Y;
            
            //CREATE T/F TO CHECK FOR LEFTBUTTON HELD DOWN
            bool leftButtonHeld = mouseData.LeftButton == MouseButtonState.Pressed;

            //LOG MOUSE POSITION TO LABEL
            lblInfo.Content = mouseX.ToString() + ", " + mouseY.ToString();

            //UPDATE POINT2D POSITION TO REFLECT MOUSE POSITION
            _mousePosition.SetPosition(mouseX, mouseY);

            if (leftButtonHeld) {                
                
                Draw();
                
            }
        }   

        private void slider_ValueChanged(object sender,RoutedPropertyChangedEventArgs<double> e) {
            byte red = (byte)sldrRed.Value;
            byte grn = (byte)sldrGreen.Value;
            byte blu = (byte)sldrBlue.Value;

            _drawColor = Color.FromRgb(red, grn, blu);

            
            mySolidColorBrush.Color = _drawColor;
            rctCurrentColor.Fill = mySolidColorBrush;
        }

        private void btnClear_Click(object sender,RoutedEventArgs e) {
            SetupBitMap();
        }

        #endregion
        
        #region METHODS
        private void SetupBitMap() {
            _bmpDraw = new BitmapMaker((int)drawPad.Width, (int)drawPad.Height);
            _bmpDraw.SetPixels(50, 15, 60);
            drawPad.Source = _bmpDraw.MakeBitmap();
        }//end method
        private void Draw() {
            //_mousePosition.SetColor(255,200,60);            
            _bmpDraw.SetPixel(_mousePosition.X + 1, _mousePosition.Y, _drawColor);
            _bmpDraw.SetPixel(_mousePosition.X - 1, _mousePosition.Y, _drawColor);
            _bmpDraw.SetPixel(_mousePosition.X, _mousePosition.Y + 1, _drawColor);
            _bmpDraw.SetPixel(_mousePosition.X, _mousePosition.Y - 1, _drawColor);
            _bmpDraw.SetPixel(_mousePosition.X, _mousePosition.Y, _drawColor);
            
            //_bmpDraw.SetPixel(_mousePosition.X, _mousePosition.Y, _mousePosition.ColorPoint);
            drawPad.Source = _bmpDraw.MakeBitmap();              
        }

        #endregion
        
    }
}
